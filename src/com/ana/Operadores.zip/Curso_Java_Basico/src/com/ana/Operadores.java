package com.ana;

public class Operadores {

    public static void main(String[] args) {

        //Operadores

        //Aritmeticos
        // + - * / %
        int number1 = 1;
        int number2 = 2;

        int resultado = number1 + number2;
        resultado = number1 - number2; // no se pone de nuevo el tipo de dato porque si no estariamos duplicando la variable. Al no poner int lo que estamos haciendo es sobreescribir el dato de la variable
        // también se puede crear una variable con un nombre distinto por ejemplo:
        int resultado2 = number1 - number2;
        int resultado3 = number2 / number1;
        int resultado4 = number1 * number2;

            //Logico, relacion, comparacion, booleanos
            /*
        >
        >=
        <
        <=
        ==
        !=
        && AND, para si se cumple una condición y otra condición
        || OR, esto O esto
        ! negación
            */

            //Asignación
            /*
        =
        +=
        -=
        /=
        *=
        %=
            */

            //Incremento
        //**

            //Decremento
        //--
        //Por ejemplo: number2--;

            //Concatenación (para concatenar string o numero con string...)
        // +
    }
}
